All of the *.exe files are for x86 processors running on 64-bit Windows.

You can re-compile the Fortran 77 codes to run on other processors or operating systems.
