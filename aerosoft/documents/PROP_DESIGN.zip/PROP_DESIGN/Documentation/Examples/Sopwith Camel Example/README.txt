This aircraft has a huge engine. So not much of the blade is making thrust.
It looks like only 50% of the blade would make thrust, for this engine/aircraft
layout. This would be a hub end point of 21. I did the analysis for hep of 11
and 21. 11 would be the ideal configuration. This estimates the shp better.
Using a value of 21 would estimate the actual thrust you would get better.
Since traditional fixed pitch propellers thicken the inboard sections, the
shp would be even higher than predicted. I left an extra 10 shp for this issue.
It's just a guess, but leaving extra shp would help.

They thicken the inboard sections because they are using wood construction.
Now days, you can use composite materials to create thin blades. These will perform
better and as predicted. You don't need to thicken the root section, because
modern materials are strong and light. You can use a small spiner to cover the
hub and root fillet.

The point of this example was to try and create a traditional fixed pitch wood
propeller with thick inboard sections. I battled with CAD software for a very
long time, to get as close as I did. I can't figure out how to exactly
generate an old type propeller. However, it's pretty close, as you can see in
the pictures. You may have more knowledge on how to get the geometry even
closer.

I purposely used a different spinner shape. The shape I used is more modern.
It's the default geometry I use. I think it looks good and it should perform
well. It's based on geometry I found on the internet.

One thing to keep in mind is the blade may be too thin for wood construction.
The examples use NACA 65A009 airoils. Old propellers usually use RAF6 or ClarkY
airfoils. These are thicker. Then, on the inboard sections they do some sort of
blend to add a lot of thickness. This is terrible for aerodynamics but is most
likely necessary, because wood is not a good material choice. It's weak, the
properties vary and are typically unknown, and it rots from water/humidity.
This is why they switched to hollow steel, then solid aluminum, then solid
composites, and lately hollow composites. As time has gone by, the blades are
lighter and stronger. They have less rotational inertia as well. So they spin
up and down faster. The gyroscopic loads are also lower, due to the reduction
in rotational inertia. This lowers stress, making the blades safer, and also
makes the aircraft more controllable.

I created the traditional geometry, as well as the ideal geometry.
