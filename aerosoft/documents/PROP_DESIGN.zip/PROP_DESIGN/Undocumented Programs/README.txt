These programs are very useful. They are undocumented, but function like the documented codes. You shouldn't have any trouble figuring out how to used them. Descriptions of the programs are below.

AIRFOIL_AND_STALL_MODEL_DATA:

This program allows you to view the airfoil and stall model data.

ANALYSIS_MESH_TEST:

This program is very useful for debugging. It makes it easy to see the difference in results caused by changes in mesh density.

ANALYSIS_MESH_TEST_TWO:

This program provides details between the default mesh density and any other mesh density that you specify. This program is also very useful for debugging. I recently took out the vortex interactions from all the codes.
I only left them in two of the undocumented codes. This is the only version you can use for design and analysis. The vortex interactions are something novel to PROPSY. They are a deviation from all previous propeller design methods. They are very difficult to code and debug. PROPSY's implementation had many problems. Over the last twelve years, I have tried to fix them. In January of 2021, I made another overhaul of the vortex interaction codes. There were bugs in what I had did previously, as well as some latent bugs from PROPSY that I didn't catch until then.
I tried my best to debug and check the new code. However, there could be cases that aren't working right. In any event, the affect is extremely small and can be ignored. My new method does not use them at all. In this code, you can add the iteractions to the new method results. This allows you to show that Theodorsen's theory is not correct.
He maintained that wake contraction was of major importance to the performance calculations. This is not the case. In fact, the wake can also expand, which is something he never considered. The vortex interactions also allow you to show that tip devices and ducting are of no benefit.

MAPS_AIRFOIL_VS_STALL:

This is a program that I love. It allows you to see the difference between using a flat plate or an airfoil. Surprisingly, a flat plat works really well. The airfoil is only needed for high speeds.

MAPS_CS:

This program compares four fixed pitch propellers to one constant speed propeller. It allows you to see the inherent error in constant speed propeller systems. However, it also shows you how much more efficient they are in climb.

The pitch for the constant speed propeller is set for the highest value input. The remaining pitch values are set by rotating the blades about the blade axis. Generally, propeller manufacturers use the 3/4 radial position to set pitch for the whole blade. You can select which station you want to set the blade pitch at, in the settings file.
Only the station you select will have the correct pitch. The rest of the radial stations will have an inherent error. Pitch values are sorted, from highest to lowest. You can still input the values in any order. However, they are output from highest to lowest. So the plot legend is a bit different than the other versions of PROP_DESIGN. In the other versions of PROP_DESIGN, the pitch values are in the order you input them. In MAPS_CS 'Pitch A' would be for the highest pitch, 'Pitch B' for the next highest, and so on.

SOLVER_MODE_COMPARISONS:

I made this code, in January of 2021, to make it easy to see the difference between the various solver methods. The default method is recommended. You can see there is a very large difference from blade element theory. This is due to the fact that blade element theory does not include induced velocities. You can also see that vortex interactions are not that significant. Blade to blade interactions can sometimes show a large difference, however, this aspect of the code is not thoroughly bug tested. I also have a lot of issues with it conceptually. The vortex and blade to blade interactions are from PROPSY. The version used in PROP_DESIGN has had many bug fixes applied. I have it here only for evaluation purposes. The default solving method is always recommended.
