These tools are undocumented. Descriptions are below:

AIRFOI_CFD_INPUTS; provides information that helps create airfoil CFD inputs

ATMOSPHERIC_PROPERTIES; provides atmospheric properties needed for performing CFD

MAX_RADIUS; this program allows you to see the maximum radius, when induced velocities are not considered. This information may be helpful, in some situations. You can use it as a starting point for OPT. OPT includes induced velocities, so the max radius for OPT will be different. You have to use OPT,
and trial and error, to find the true max radius.

VELOCITY_CONVERSION; computes aircraft velocity input for use with PROP_DESIGN
