
ESPROP 0.8 Read Me                                    8 Oct 2011
----------------------------------------------------------------
Esotec Developments                 philip (at) esotec (dot) org


ESPROP and its plot library should compile on any Unix system
with Fortran 77, C, and X-Windows support (including xorg-dev).

Makefiles are currently configured for Ubuntu/gfortran. Configure 
config.make in plotlib and Makefile in bin for your system.

Build sequence
--------------

1. Build plot library in ./plotlib (as in XROTOR)
   % cd plotlib
     Edit compiler flags for your machine in config.make
   % make

2. Build esprop in ./bin
   % cd bin
     Edit compiler flags for your machine in Makefile
   % make
  

Go to the CROTOR package for Win build (win32 binary included in this package).

PJC
