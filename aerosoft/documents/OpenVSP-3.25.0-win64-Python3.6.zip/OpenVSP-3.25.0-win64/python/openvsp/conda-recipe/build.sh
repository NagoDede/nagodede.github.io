#!/bin/bash

$PYTHON setup.py sdist install  --single-version-externally-managed --record=record.txt