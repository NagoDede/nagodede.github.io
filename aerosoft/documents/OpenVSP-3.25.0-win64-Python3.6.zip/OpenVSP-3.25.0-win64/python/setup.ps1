conda env create -f .\environment.yml
conda activate vsppytools
pip install -r requirements-dev.txt
